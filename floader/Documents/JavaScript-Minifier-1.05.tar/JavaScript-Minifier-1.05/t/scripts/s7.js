var x = 1; /*asdf*/
 /*asdf*/
  /*asdf*/
   /*asdf*/
  // aaaaa
  //@ a
  /**/
  //
  //@ a
  //@ a
  /*@*//**//*@*/
  /*@*/
    
   /* asdfasdf asdf asdf
    * asdfasdfa
    * asdfasdfa
    *//**/

    /* asdfasdf asdf asdf
     * asdfasdfa
     * asdfasdfa
     */
    
   var x = 1;
   
   