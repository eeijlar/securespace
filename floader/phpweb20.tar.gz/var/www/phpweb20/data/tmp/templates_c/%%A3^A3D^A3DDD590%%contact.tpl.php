<?php /* Smarty version 2.6.18, created on 2009-05-29 08:32:40
         compiled from contact/contact.tpl */ ?>
<div id="content">
	  <div id="mainContent">
			<img src="../images/secure-online.jpg" alt="Secure Online Counselling" />
			<h2><span class="backgroundGrey">Contact Us</span></h2>
  
<p>If you are interested in receiving online counselling please all you have to do is select the counsellor you want to work with. Click <a href="http://www.securecounselling.ie/sme/view">here</a> to select your counsellor.</p>


<p>For general queries regarding the service contact:</p>
<p><img src="../images/info.png" alt="info email"/></p>
<p>For technical support please contact:</p>
<p><img src="../images/support.png" alt="support email"/></p>
<p>If you would like to provide feedback on any aspect of the service contact:</p>
<p><img src="../images/feedback.png" alt="feedback email"/></p>
<p>If you found a bug in the site please send us a mail at:</p>
<p><img src="../images/bugs.png" alt="bugs email"/></p>



          </div>

                <!-- mainContent --> 