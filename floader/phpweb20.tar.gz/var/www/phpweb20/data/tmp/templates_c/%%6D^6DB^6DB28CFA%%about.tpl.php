<?php /* Smarty version 2.6.18, created on 2009-03-11 23:59:24
         compiled from about.tpl */ ?>
<div id="content">
	  <div id="mainContent">
			<img src="../images/secure-online.jpg" alt="Secure Online Counselling" />
			<h2><span class="backgroundGrey">About Secure Counselling</span></h2>
			
		    <p></p>
			<h3><span class="backgroundGrey">Security</span></h3>
			
		    <p></p>
		    
			<p></p>
	  </div>
		<!-- mainContent -->