<?php /* Smarty version 2.6.18, created on 2010-04-30 15:47:48
         compiled from header.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>Secure Counselling - Online Counselling &amp; Therapy Ireland</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
	<link rel="stylesheet" type="text/css" href="/css/styles.css" media="all"/>
	<script type ="text/javascript" src="/js/prototype.js"></script>
	<script type ="text/javascript" src="/js/scriptaculous/scriptaculous.js"></script>
	<script type="text/javascript" src="/js/CheckRegistrationForm.js"></script>	
        <meta name="Description" content="Private and secure online counselling. Confidential service with reasonable rates."/>
        <meta name="google-site-verification" content="OsgzsTzhZq7CdQ6S5QsH-xj51XkL3AzgMFvolTawfF4"/>
	<link rel="shortcut icon" href="/favicon.ico" />
	</head>
	<body>
 <div id="wrapper">
	<div id="mastHead">
		<h1>Secure Counselling and Therapy Ireland</h1>
	</div><!-- mastHead -->
    		<div id="mainNav">		      
		      
			        <ul>
			          <li><a href="/index" accesskey="a">Home</a></li>			
			          <li><a href="/about/index">What is Online Counselling?</a></li>
			          <li><a href="/services/index" accesskey="r">Services </a></li>
					  <li><a href="/solutions/index" accesskey="3">Technical Solutions</a></li>
					  <li><a href="/contact/index" accesskey="4">Contact Us</a></li>
    				</ul>		
			</div><!--mainnav-->