<?php /* Smarty version 2.6.18, created on 2010-09-01 21:24:05
         compiled from sidebar.tpl */ ?>
				<div id="sidebar">
					<div id="sideNav">
						<ul>
						    <li><a href="/account/login" accesskey="r"><strong>Login for Counselling</strong></a>        
		  		            <li><a href="/sme/view" accesskey="r"><strong>Register</strong></a></li>
			                <li><a href="/online/index" accesskey="1">Online Counselling</a></li>
		              		<li><a href="/training/index" accesskey="2">Counsellor Training</a></li>
		              		<li><a href="/consultancy/index" accesskey="3">Consultancy</a></li>
		        	</ul>
				  <h3>Your Privacy Is Our Priority </h3>
                                  <img style="margin-left:43px" src="../images/seals/InstantSSL-DV_tl_white.gif" alt="Comodo Seal" /> 
			  </div><!--sidebarnav-->
                              <div id="survey">
                                         <h4>We would like your feedback... click the image below to take our short survey</h4> <a href="http://www.surveymonkey.com/s/Q6CKNNT" target="_blank"> <img src="../images/Piechart.png" alt="Survey" border="0" style="margin-left:65px"/></a>
                             </div> 
			  </div><!--sidebar-->
