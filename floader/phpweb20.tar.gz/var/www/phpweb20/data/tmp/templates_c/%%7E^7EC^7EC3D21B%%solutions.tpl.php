<?php /* Smarty version 2.6.18, created on 2009-10-07 12:15:25
         compiled from solutions/solutions.tpl */ ?>
<div id="content">
	  <div id="mainContent">
			<img src="../images/secure-online.jpg" alt="Secure Online Counselling" />
			<h2><span class="backgroundGrey">Secure Space Limited</span></h2>
			
		    
			



			<p>Secure
Space is a framework to provide secure comunications for clients and their service providers. Secure Space is
a versatile software product that can meet the demands of a variety of
organisations and companies. </p>

			<p>The range of applications include healthcare, law, government, military, among others. </p>

                 <p><a href="http://www.securespace.ie/technology/technology.html">Secure Space Technology</a </p>
          </div>

                <!-- mainContent --> 