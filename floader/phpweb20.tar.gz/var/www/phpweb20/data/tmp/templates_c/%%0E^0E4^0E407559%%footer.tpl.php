<?php /* Smarty version 2.6.18, created on 2010-05-09 16:47:02
         compiled from footer.tpl */ ?>
</div> <!--content5-->

                <?php if ($this->_tpl_vars['authenticated']): ?>
                <div id="footer">
                        <?php else: ?>
                        <div id="footer">
                        <?php endif; ?>
                        <p>Copyright &copy; Secure Space Ltd. 2008.&nbsp; Registration No.:461261 All rights reserved.
                        Powered by <a href="http://www.securespace.ie">Secure Space Ltd.</a></p>
                        </div>
</div> <!--content-->
<!--wide</div>-->
</body>
</html>