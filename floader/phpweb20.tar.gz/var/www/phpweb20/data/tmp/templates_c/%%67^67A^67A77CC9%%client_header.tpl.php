<?php /* Smarty version 2.6.18, created on 2009-05-26 14:52:41
         compiled from client_header.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <title>Secure Counselling</title>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
        <link rel="stylesheet" type="text/css" href="/css/styles.css" media="all"/>
        <script type ="text/javascript" src="/js/prototype.js"></script>
        <script type ="text/javascript" src="/js/scriptaculous/scriptaculous.js"></script>
        <script type="text/javascript" src="/js/CheckRegistrationForm.js"></script>
        </head>
        <body  onload="updateCountryPhoneCodeOnChangeInit();">
        <div id="wrapper">
          <div id="mastHead">
                <h1>Secure Counselling and Therapy Ireland</h1>
          </div><!-- mastHead -->
                <div id="mainNav">
                         <ul>
                           <li><a href="/index" accesskey="a">Home</a></li>
                           <li><a href="/index">What is Online Counselling? </a></li>
                           <li><a href="/index" accesskey="r">Services </a></li>
                           <li><a href="/index" accesskey="3">Technical Solutions</a></li>
                           <li><a href="/index" accesskey="4">Contact Us</a></li>
                          </ul>
                </div><!--mainnav-->
