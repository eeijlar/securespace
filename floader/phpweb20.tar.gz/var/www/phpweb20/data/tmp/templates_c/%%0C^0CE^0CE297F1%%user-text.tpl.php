<?php /* Smarty version 2.6.18, created on 2009-05-29 16:35:24
         compiled from mobile/user-text.tpl */ ?>
Dear <?php echo $this->_tpl_vars['user']->profile->first_name; ?>
, your <?php echo $this->_tpl_vars['website']; ?>
 application is complete. Check your e-mail for details. 