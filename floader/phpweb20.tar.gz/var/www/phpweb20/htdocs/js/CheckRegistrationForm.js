	countryCodes = new Array();
  intlDialCodeLabels = new Array();
  
  	countryCodes[0] = "PE";
    intlDialCodeLabels[0] = "51";
  
  	countryCodes[1] = "LA";
    intlDialCodeLabels[1] = "856";
  
  	countryCodes[2] = "QA";
    intlDialCodeLabels[2] = "974";
  
  	countryCodes[3] = "KE";
    intlDialCodeLabels[3] = "254";
  
  	countryCodes[4] = "MN";
    intlDialCodeLabels[4] = "976";
  
  	countryCodes[5] = "CF";
    intlDialCodeLabels[5] = "236";
  
  	countryCodes[6] = "SM";
    intlDialCodeLabels[6] = "378";
  
  	countryCodes[7] = "TV";
    intlDialCodeLabels[7] = "688";
  
  	countryCodes[8] = "DE";
    intlDialCodeLabels[8] = "49";
  
  	countryCodes[9] = "SR";
    intlDialCodeLabels[9] = "597";
  
  	countryCodes[10] = "DZ";
    intlDialCodeLabels[10] = "213";
  
  	countryCodes[11] = "CK";
    intlDialCodeLabels[11] = "682";
  
  	countryCodes[12] = "YE";
    intlDialCodeLabels[12] = "967";
  
  	countryCodes[13] = "MQ";
    intlDialCodeLabels[13] = "596";
  
  	countryCodes[14] = "ZM";
    intlDialCodeLabels[14] = "260";
  
  	countryCodes[15] = "NG";
    intlDialCodeLabels[15] = "234";
  
  	countryCodes[16] = "BW";
    intlDialCodeLabels[16] = "267";
  
  	countryCodes[17] = "SI";
    intlDialCodeLabels[17] = "386";
  
  	countryCodes[18] = "HT";
    intlDialCodeLabels[18] = "509";
  
  	countryCodes[19] = "SN";
    intlDialCodeLabels[19] = "221";
  
  	countryCodes[20] = "YT";
    intlDialCodeLabels[20] = "269";
  
  	countryCodes[21] = "CD";
    intlDialCodeLabels[21] = "243";
  
  	countryCodes[22] = "GN";
    intlDialCodeLabels[22] = "224";
  
  	countryCodes[23] = "MT";
    intlDialCodeLabels[23] = "356";
  
  	countryCodes[24] = "SO";
    intlDialCodeLabels[24] = "252";
  
  	countryCodes[25] = "WS";
    intlDialCodeLabels[25] = "685";
  
  	countryCodes[26] = "GB";
    intlDialCodeLabels[26] = "44";
  
  	countryCodes[27] = "LC";
    intlDialCodeLabels[27] = "1758";
  
  	countryCodes[28] = "FI";
    intlDialCodeLabels[28] = "358";
  
  	countryCodes[29] = "HU";
    intlDialCodeLabels[29] = "36";
  
  	countryCodes[30] = "KG";
    intlDialCodeLabels[30] = "996";
  
  	countryCodes[31] = "JM";
    intlDialCodeLabels[31] = "1876";
  
  	countryCodes[32] = "MR";
    intlDialCodeLabels[32] = "222";
  
  	countryCodes[33] = "JO";
    intlDialCodeLabels[33] = "962";
  
  	countryCodes[34] = "SV";
    intlDialCodeLabels[34] = "503";
  
  	countryCodes[35] = "EC";
    intlDialCodeLabels[35] = "593";
  
  	countryCodes[36] = "MP";
    intlDialCodeLabels[36] = "1670";
  
  	countryCodes[37] = "GE";
    intlDialCodeLabels[37] = "995";
  
  	countryCodes[38] = "MK";
    intlDialCodeLabels[38] = "389";
  
  	countryCodes[39] = "OM";
    intlDialCodeLabels[39] = "968";
  
  	countryCodes[40] = "CS";
    intlDialCodeLabels[40] = "381";
  
  	countryCodes[41] = "GF";
    intlDialCodeLabels[41] = "594";
  
  	countryCodes[42] = "LB";
    intlDialCodeLabels[42] = "961";
  
  	countryCodes[43] = "CG";
    intlDialCodeLabels[43] = "242";
  
  	countryCodes[44] = "ST";
    intlDialCodeLabels[44] = "239";
  
  	countryCodes[45] = "MU";
    intlDialCodeLabels[45] = "230";
  
  	countryCodes[46] = "SL";
    intlDialCodeLabels[46] = "232";
  
  	countryCodes[47] = "SA";
    intlDialCodeLabels[47] = "966";
  
  	countryCodes[48] = "US";
    intlDialCodeLabels[48] = "1";
  
  	countryCodes[49] = "MO";
    intlDialCodeLabels[49] = "853";
  
  	countryCodes[50] = "GD";
    intlDialCodeLabels[50] = "1473";
  
  	countryCodes[51] = "GA";
    intlDialCodeLabels[51] = "241";
  
  	countryCodes[52] = "BA";
    intlDialCodeLabels[52] = "387";
  
  	countryCodes[53] = "KZ";
    intlDialCodeLabels[53] = "7";
  
  	countryCodes[54] = "CH";
    intlDialCodeLabels[54] = "41";
  
  	countryCodes[55] = "SY";
    intlDialCodeLabels[55] = "963";
  
  	countryCodes[56] = "BB";
    intlDialCodeLabels[56] = "1246";
  
  	countryCodes[57] = "KY";
    intlDialCodeLabels[57] = "1345";
  
  	countryCodes[58] = "BV";
    intlDialCodeLabels[58] = "672";
  
  	countryCodes[59] = "GL";
    intlDialCodeLabels[59] = "299";
  
  	countryCodes[60] = "AD";
    intlDialCodeLabels[60] = "376";
  
  	countryCodes[61] = "RO";
    intlDialCodeLabels[61] = "40";
  
  	countryCodes[62] = "WF";
    intlDialCodeLabels[62] = "681";
  
  	countryCodes[63] = "IL";
    intlDialCodeLabels[63] = "972";
  
  	countryCodes[64] = "KP";
    intlDialCodeLabels[64] = "850";
  
  	countryCodes[65] = "MS";
    intlDialCodeLabels[65] = "1664";
  
  	countryCodes[66] = "CN";
    intlDialCodeLabels[66] = "86";
  
  	countryCodes[67] = "VI";
    intlDialCodeLabels[67] = "1340";
  
  	countryCodes[68] = "NL";
    intlDialCodeLabels[68] = "31";
  
  	countryCodes[69] = "SK";
    intlDialCodeLabels[69] = "421";
  
  	countryCodes[70] = "BY";
    intlDialCodeLabels[70] = "375";
  
  	countryCodes[71] = "IO";
    intlDialCodeLabels[71] = "246";
  
  	countryCodes[72] = "UA";
    intlDialCodeLabels[72] = "380";
  
  	countryCodes[73] = "AG";
    intlDialCodeLabels[73] = "1268";
  
  	countryCodes[74] = "GM";
    intlDialCodeLabels[74] = "220";
  
  	countryCodes[75] = "AE";
    intlDialCodeLabels[75] = "971";
  
  	countryCodes[76] = "PL";
    intlDialCodeLabels[76] = "48";
  
  	countryCodes[77] = "EE";
    intlDialCodeLabels[77] = "372";
  
  	countryCodes[78] = "CL";
    intlDialCodeLabels[78] = "56";
  
  	countryCodes[79] = "MV";
    intlDialCodeLabels[79] = "960";
  
  	countryCodes[80] = "SD";
    intlDialCodeLabels[80] = "249";
  
  	countryCodes[81] = "NA";
    intlDialCodeLabels[81] = "264";
  
  	countryCodes[82] = "CM";
    intlDialCodeLabels[82] = "237";
  
  	countryCodes[83] = "PK";
    intlDialCodeLabels[83] = "92";
  
  	countryCodes[84] = "BZ";
    intlDialCodeLabels[84] = "501";
  
  	countryCodes[85] = "SG";
    intlDialCodeLabels[85] = "65";
  
  	countryCodes[86] = "ID";
    intlDialCodeLabels[86] = "62";
  
  	countryCodes[87] = "PS";
    intlDialCodeLabels[87] = "970";
  
  	countryCodes[88] = "NC";
    intlDialCodeLabels[88] = "687";
  
  	countryCodes[89] = "BT";
    intlDialCodeLabels[89] = "975";
  
  	countryCodes[90] = "GY";
    intlDialCodeLabels[90] = "592";
  
  	countryCodes[91] = "DO";
    intlDialCodeLabels[91] = "1809";
  
  	countryCodes[92] = "KR";
    intlDialCodeLabels[92] = "82";
  
  	countryCodes[93] = "CO";
    intlDialCodeLabels[93] = "57";
  
  	countryCodes[94] = "HR";
    intlDialCodeLabels[94] = "385";
  
  	countryCodes[95] = "BS";
    intlDialCodeLabels[95] = "1242";
  
  	countryCodes[96] = "FR";
    intlDialCodeLabels[96] = "33";
  
  	countryCodes[97] = "SE";
    intlDialCodeLabels[97] = "46";
  
  	countryCodes[98] = "MW";
    intlDialCodeLabels[98] = "265";
  
  	countryCodes[99] = "SH";
    intlDialCodeLabels[99] = "290";
  
  	countryCodes[100] = "NE";
    intlDialCodeLabels[100] = "227";
  
  	countryCodes[101] = "AF";
    intlDialCodeLabels[101] = "93";
  
  	countryCodes[102] = "PG";
    intlDialCodeLabels[102] = "675";
  
  	countryCodes[103] = "IE";
    intlDialCodeLabels[103] = "353";
  
  	countryCodes[104] = "SZ";
    intlDialCodeLabels[104] = "268";
  
  	countryCodes[105] = "CI";
    intlDialCodeLabels[105] = "225";
  
  	countryCodes[106] = "HK";
    intlDialCodeLabels[106] = "852";
  
  	countryCodes[107] = "AZ";
    intlDialCodeLabels[107] = "994";
  
  	countryCodes[108] = "PH";
    intlDialCodeLabels[108] = "63";
  
  	countryCodes[109] = "NF";
    intlDialCodeLabels[109] = "672";
  
  	countryCodes[110] = "PR";
    intlDialCodeLabels[110] = "1787";
  
  	countryCodes[111] = "IN";
    intlDialCodeLabels[111] = "91";
  
  	countryCodes[112] = "ZA";
    intlDialCodeLabels[112] = "27";
  
  	countryCodes[113] = "AI";
    intlDialCodeLabels[113] = "1264";
  
  	countryCodes[114] = "TT";
    intlDialCodeLabels[114] = "1868";
  
  	countryCodes[115] = "PA";
    intlDialCodeLabels[115] = "507";
  
  	countryCodes[116] = "KH";
    intlDialCodeLabels[116] = "855";
  
  	countryCodes[117] = "PT";
    intlDialCodeLabels[117] = "351";
  
  	countryCodes[118] = "PF";
    intlDialCodeLabels[118] = "689";
  
  	countryCodes[119] = "SJ";
    intlDialCodeLabels[119] = "47";
  
  	countryCodes[120] = "KI";
    intlDialCodeLabels[120] = "686";

  
  	countryCodes[121] = "IQ";
    intlDialCodeLabels[121] = "964";
  
  	countryCodes[122] = "FO";
    intlDialCodeLabels[122] = "298";
  
  	countryCodes[123] = "VG";
    intlDialCodeLabels[123] = "1284";
  
  	countryCodes[124] = "DM";
    intlDialCodeLabels[124] = "1767";
  
  	countryCodes[125] = "NI";
    intlDialCodeLabels[125] = "505";
  
  	countryCodes[126] = "VN";
    intlDialCodeLabels[126] = "84";
  
  	countryCodes[127] = "ET";
    intlDialCodeLabels[127] = "251";
  
  	countryCodes[128] = "LK";
    intlDialCodeLabels[128] = "94";
  
  	countryCodes[129] = "AS";
    intlDialCodeLabels[129] = "684";
  
  	countryCodes[130] = "CX";
    intlDialCodeLabels[130] = "61";
  
  	countryCodes[131] = "ER";
    intlDialCodeLabels[131] = "291";
  
  	countryCodes[132] = "MZ";
    intlDialCodeLabels[132] = "258";
  
  	countryCodes[133] = "VC";
    intlDialCodeLabels[133] = "1784";
  
  	countryCodes[134] = "AN";
    intlDialCodeLabels[134] = "599";
  
  	countryCodes[135] = "KN";
    intlDialCodeLabels[135] = "1869";
  
  	countryCodes[136] = "VE";
    intlDialCodeLabels[136] = "58";
  
  	countryCodes[137] = "TR";
    intlDialCodeLabels[137] = "90";
  
  	countryCodes[138] = "BD";
    intlDialCodeLabels[138] = "880";
  
  	countryCodes[139] = "TO";
    intlDialCodeLabels[139] = "676";
  
  	countryCodes[140] = "BJ";
    intlDialCodeLabels[140] = "229";
  
  	countryCodes[141] = "GR";
    intlDialCodeLabels[141] = "30";
  
  	countryCodes[142] = "RE";
    intlDialCodeLabels[142] = "262";
  
  	countryCodes[143] = "PN";
    intlDialCodeLabels[143] = "649";
  
  	countryCodes[144] = "MC";
    intlDialCodeLabels[144] = "377";
  
  	countryCodes[145] = "TJ";
    intlDialCodeLabels[145] = "992";
  
  	countryCodes[146] = "AQ";
    intlDialCodeLabels[146] = "672";
  
  	countryCodes[147] = "BF";
    intlDialCodeLabels[147] = "226";
  
  	countryCodes[148] = "TM";
    intlDialCodeLabels[148] = "993";
  
  	countryCodes[149] = "UY";
    intlDialCodeLabels[149] = "598";
  
  	countryCodes[150] = "AU";
    intlDialCodeLabels[150] = "61";
  
  	countryCodes[151] = "IR";
    intlDialCodeLabels[151] = "98";
  
  	countryCodes[152] = "GP";
    intlDialCodeLabels[152] = "590";
  
  	countryCodes[153] = "TN";
    intlDialCodeLabels[153] = "216";
  
  	countryCodes[154] = "MH";
    intlDialCodeLabels[154] = "692";
  
  	countryCodes[155] = "AT";
    intlDialCodeLabels[155] = "43";
  
  	countryCodes[156] = "GQ";
    intlDialCodeLabels[156] = "240";
  
  	countryCodes[157] = "CZ";
    intlDialCodeLabels[157] = "420";
  
  	countryCodes[158] = "GH";
    intlDialCodeLabels[158] = "233";
  
  	countryCodes[159] = "MG";
    intlDialCodeLabels[159] = "261";
  
  	countryCodes[160] = "AM";
    intlDialCodeLabels[160] = "374";
  
  	countryCodes[161] = "UZ";
    intlDialCodeLabels[161] = "998";
  
  	countryCodes[162] = "TK";
    intlDialCodeLabels[162] = "690";
  
  	countryCodes[163] = "PM";
    intlDialCodeLabels[163] = "508";
  
  	countryCodes[164] = "LT";
    intlDialCodeLabels[164] = "370";
  
  	countryCodes[165] = "BE";
    intlDialCodeLabels[165] = "32";
  
  	countryCodes[166] = "MY";
    intlDialCodeLabels[166] = "60";
  
  	countryCodes[167] = "RU";
    intlDialCodeLabels[167] = "7";
  
  	countryCodes[168] = "BG";
    intlDialCodeLabels[168] = "359";
  
  	countryCodes[169] = "AO";
    intlDialCodeLabels[169] = "244";
  
  	countryCodes[170] = "AL";
    intlDialCodeLabels[170] = "355";
  
  	countryCodes[171] = "AW";
    intlDialCodeLabels[171] = "297";
  
  	countryCodes[172] = "MX";
    intlDialCodeLabels[172] = "52";
  
  	countryCodes[173] = "IT";
    intlDialCodeLabels[173] = "39";
  
  	countryCodes[174] = "BR";
    intlDialCodeLabels[174] = "55";
  
  	countryCodes[175] = "RW";
    intlDialCodeLabels[175] = "250";
  
  	countryCodes[176] = "BI";
    intlDialCodeLabels[176] = "257";
  
  	countryCodes[177] = "CY";
    intlDialCodeLabels[177] = "357";
  
  	countryCodes[178] = "KM";
    intlDialCodeLabels[178] = "269";
  
  	countryCodes[179] = "GI";
    intlDialCodeLabels[179] = "350";
  
  	countryCodes[180] = "EG";
    intlDialCodeLabels[180] = "20";
  
  	countryCodes[181] = "SC";
    intlDialCodeLabels[181] = "248";
  
  	countryCodes[182] = "TD";
    intlDialCodeLabels[182] = "235";
  
  	countryCodes[183] = "VA";
    intlDialCodeLabels[183] = "39";
  
  	countryCodes[184] = "CR";
    intlDialCodeLabels[184] = "506";
  
  	countryCodes[185] = "VU";
    intlDialCodeLabels[185] = "678";
  
  	countryCodes[186] = "UG";
    intlDialCodeLabels[186] = "256";
  
  	countryCodes[187] = "BO";
    intlDialCodeLabels[187] = "591";
  
  	countryCodes[188] = "ZW";
    intlDialCodeLabels[188] = "263";
  
  	countryCodes[189] = "NP";
    intlDialCodeLabels[189] = "977";
  
  	countryCodes[190] = "SB";
    intlDialCodeLabels[190] = "677";
  
  	countryCodes[191] = "GU";
    intlDialCodeLabels[191] = "671";
  
  	countryCodes[192] = "HM";
    intlDialCodeLabels[192] = "672";
  
  	countryCodes[193] = "TC";
    intlDialCodeLabels[193] = "1649";
  
  	countryCodes[194] = "TH";
    intlDialCodeLabels[194] = "66";
  
  	countryCodes[195] = "MA";
    intlDialCodeLabels[195] = "212";
  
  	countryCodes[196] = "ML";
    intlDialCodeLabels[196] = "223";
  
  	countryCodes[197] = "LR";
    intlDialCodeLabels[197] = "231";
  
  	countryCodes[198] = "JP";
    intlDialCodeLabels[198] = "81";
  
  	countryCodes[199] = "DK";
    intlDialCodeLabels[199] = "45";
  
  	countryCodes[200] = "TL";
    intlDialCodeLabels[200] = "670";
  
  	countryCodes[201] = "HN";
    intlDialCodeLabels[201] = "504";
  
  	countryCodes[202] = "NR";
    intlDialCodeLabels[202] = "674";
  
  	countryCodes[203] = "LS";
    intlDialCodeLabels[203] = "266";
  
  	countryCodes[204] = "FJ";
    intlDialCodeLabels[204] = "679";
  
  	countryCodes[205] = "DJ";
    intlDialCodeLabels[205] = "253";
  
  	countryCodes[206] = "TZ";
    intlDialCodeLabels[206] = "255";
  
  	countryCodes[207] = "MM";
    intlDialCodeLabels[207] = "95";
  
  	countryCodes[208] = "BH";
    intlDialCodeLabels[208] = "973";
  
  	countryCodes[209] = "BM";
    intlDialCodeLabels[209] = "1441";
  
  	countryCodes[210] = "CU";
    intlDialCodeLabels[210] = "53";
  
  	countryCodes[211] = "LI";
    intlDialCodeLabels[211] = "423";
  
  	countryCodes[212] = "PY";
    intlDialCodeLabels[212] = "595";
  
  	countryCodes[213] = "PW";
    intlDialCodeLabels[213] = "680";
  
  	countryCodes[214] = "BN";
    intlDialCodeLabels[214] = "673";
  
  	countryCodes[215] = "IS";
    intlDialCodeLabels[215] = "354";
  
  	countryCodes[216] = "GS";
    intlDialCodeLabels[216] = "500";
  
  	countryCodes[217] = "LV";
    intlDialCodeLabels[217] = "371";
  
  	countryCodes[218] = "TF";
    intlDialCodeLabels[218] = "672";
  
  	countryCodes[219] = "NO";
    intlDialCodeLabels[219] = "47";
  
  	countryCodes[220] = "GT";
    intlDialCodeLabels[220] = "502";
  
  	countryCodes[221] = "MD";
    intlDialCodeLabels[221] = "373";
  
  	countryCodes[222] = "FK";
    intlDialCodeLabels[222] = "500";
  
  	countryCodes[223] = "LY";
    intlDialCodeLabels[223] = "218";
  
  	countryCodes[224] = "ES";
    intlDialCodeLabels[224] = "34";
  
  	countryCodes[225] = "TW";
    intlDialCodeLabels[225] = "886";
  
  	countryCodes[226] = "UM";
    intlDialCodeLabels[226] = "1808";
  
  	countryCodes[227] = "KW";
    intlDialCodeLabels[227] = "965";
  
  	countryCodes[228] = "CA";
    intlDialCodeLabels[228] = "1";
  
  	countryCodes[229] = "FM";
    intlDialCodeLabels[229] = "691";
  
  	countryCodes[230] = "TG";
    intlDialCodeLabels[230] = "228";
  
  	countryCodes[231] = "NU";
    intlDialCodeLabels[231] = "683";
  
  	countryCodes[232] = "GW";
    intlDialCodeLabels[232] = "245";
  
  	countryCodes[233] = "AR";
    intlDialCodeLabels[233] = "54";
  
  	countryCodes[234] = "CC";
    intlDialCodeLabels[234] = "61";
  
  	countryCodes[235] = "LU";
    intlDialCodeLabels[235] = "352";
  
  	countryCodes[236] = "NZ";
    intlDialCodeLabels[236] = "64";
  
  	countryCodes[237] = "CV";
    intlDialCodeLabels[237] = "238";

  
                    
	function updateCountryCode(countryCode) {
		for (i=0;i<intlDialCodeLabels.length;i++)	{
			if (countryCode == countryCodes[i]) {
				document.getElementById('displayIntlDialCode').innerHTML="+"+ intlDialCodeLabels[i];
				document.registration.countryCode.value="+"+ intlDialCodeLabels[i];
    		return;
			}
		}
	}    

	function updateCountryPhoneCodeOnChangeInit() {
		var countryCode = document.registration.phoneCountry.value;
		for (i=0;i<intlDialCodeLabels.length;i++)	{
			if (countryCode == countryCodes[i]) {
				document.getElementById('displayIntlDialCode').innerHTML="+"+ intlDialCodeLabels[i];
				document.registration.countryCode.value="+"+ intlDialCodeLabels[i];
    		return;
			}
		}
	}   	

	function updateMobileNumber(countryCode,areaCode,localNumber) {
		
		document.getElementById('displayMobileOK').innerHTML = "";
		document.getElementById('displayMobile').innerHTML = "";
		
		if (!IsNumeric(areaCode)){
			document.getElementById('displayMobile').innerHTML = "Sorry! - Area Code is not a number";
			return;
		} 
		else if (!IsNumeric(localNumber)){
			document.getElementById('displayMobile').innerHTML = "Sorry! - Local number is not a number";
			return;
		}
		else if (countryCode =="+353" && (localNumber.length < 7 || localNumber.length > 7)) {
			document.getElementById('displayMobile').innerHTML = "Sorry! - Irish mobile numbers should have 7 digits, you have " + localNumber.length; 
			return;
		} 		
		else {
		 	document.getElementById('displayMobileOK').innerHTML = "Mobile Number: " + countryCode + areaCode + localNumber;
			return;
		}
	}  

	function isValidLastName(sText) {
		document.getElementById('lastNameError').innerHTML="";
		if(isBlank(sText)) {
			document.getElementById('lastNameError').innerHTML = "Last name is blank.";
		} 
		else if(sText.length < 2) {
			document.getElementById('lastNameError').innerHTML = "Last name is too short.";
		}
		
		else if (!isAlphabetic(sText)) {
			document.getElementById('lastNameError').innerHTML = "Last name contains illegal characters.";
		}
		return;
	}

	function isValidFirstName(sText) {
		 document.getElementById('firstNameError').innerHTML="";
		
		if(isBlank(sText)) {
			document.getElementById('firstNameError').innerHTML = "First name is blank.";
		} 
		else if(sText.length < 2) {
			document.getElementById('firstNameError').innerHTML = "First name is too short.";
		}
		
		else if (!isAlphabetic(sText)) {
			document.getElementById('firstNameError').innerHTML = "First name contains illegal characters.";
		}
		return;
	}

   	function isValidUserName(sText) {
   		document.getElementById('usernameerror').innerHTML="";
   		if(sText.length ==0){
   	   		document.getElementById('usernameerror').innerHTML = "Username is blank";
   	   	}
   	   	else if(sText.length < 5) {
	   	   	document.getElementById('usernameerror').innerHTML = "Username is too short - it should be at least 5 characters";
   	   	}
   	   	
   	   	else if(!isAlphaNumeric(sText)){
   	 		document.getElementById('usernameerror').innerHTML = "Username can only contain letters and digits";
   	   	}	   	   
   	return;
   	}

   	function isValidEmail(sText) {
		   	document.getElementById('emailerror').innerHTML ="";
   	   		if(isDisallowedCharacter(sText)){
   	   			document.getElementById('emailerror').innerHTML = "Invalid character in e-mail address";
   	   		}	
   	   		else {
   	   			document.getElementById('emailerror').innerHTML = checkEmail(sText);
   	   		}
   	   
   	return;
   	}

	function IsNumeric(sText) {
   	   var ValidChars = "0123456789";
	   var IsNumber=true;
	   var Char;
	
	   if(sText == "") {
	   		IsNumber = false;
	   }	
	   else {
	   for (i = 0; i < sText.length && IsNumber == true; i++) 
	      { 
	      Char = sText.charAt(i); 
	      if (ValidChars.indexOf(Char) == -1) 
	         {
	         IsNumber = false;
	         }
	      }
	     }
	   return IsNumber;
   
   	}
   	
   	function isAlphaNumeric(sText) {
  
       var ValidChars = "0123456789abcedefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	   var isAlphaNumeric=true;
	   var Char;
	
	   if(sText == "") {
	   		isAlphaNumeric = false;
	   }	
	   else {
	   for (i = 0; i < sText.length && isAlphaNumeric == true; i++) 
	      { 
	      Char = sText.charAt(i); 
	      if (ValidChars.indexOf(Char) == -1) 
	         {
	         isAlphaNumeric = false;
	         }
	      }
	     }
	   return isAlphaNumeric; 	
   	
   	}
   	
   	function isAlphabetic(sText) {
  
       var ValidChars = ".abcedefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	   var isAlphaNumeric=true;
	   var Char;
	
	   if(sText == "") {
	   		isAlphaNumeric = false;
	   }	
	   else {
	   for (i = 0; i < sText.length && isAlphaNumeric == true; i++) 
	      { 
	      Char = sText.charAt(i); 
	      if (ValidChars.indexOf(Char) == -1) 
	         {
	         isAlphaNumeric = false;
	         }
	      }
	     }
	   return isAlphaNumeric; 	
   	
   	}   	
   	
   	function isDisallowedCharacter(sText) {
   	   var invalidChars="!#$%(),:;<>?[\]|";
	   var isDisallowed=false;
	   var Char;
	
	   if(sText == "") {
	   		isDisallowed = true;
	   }	
	   else {
	   for (i = 0; i < sText.length && isDisallowed == false; i++) 
	      { 
	      Char = sText.charAt(i); 
	      if (invalidChars.indexOf(Char) != -1) 
	         {
	         isDisallowed = true;
	         }
	      }
	     }
	   return isDisallowed;
   	}

	function stripZero(sText) {
		var result = sText;
		if (IsNumeric(result)) {
     		while (result.substring(0,1) == "0") {
     			result = result.substring(1,result.length);
    		}
    	} else {
    		document.getElementById('displayMobile').innerHTML = "Oops! - Area Code is not a number";
    	}
    	return result;
	} 	
   	
   	function isBlank(sText){
   		if(sText.length == 0){
			return true;  
			 		
   		} else {
   			
   			return false;
   		}
   	}
   	
   	function checkAddressMatch(email,verifyEmail) {
   		document.getElementById('emailerror').innerHTML =""
   		document.getElementById('verifyemailerror').innerHTML=""
   		
   		if(email != verifyEmail) {
   	   		document.getElementById('verifyemailerror').innerHTML = "Email addresses do not match";
   	   }
   	return;
   	}
   	
	function checkEmail(str) {
	
			var at="@";
			var dot=".";
			var lat=str.indexOf(at);
			var lstr=str.length;
			var ldot=str.indexOf(dot);
			if (str.indexOf(at)==-1){
			   return "Email address is invalid";
			}
	
			if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
			   return "Email address is invalid";
			}
	
			if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
			   return "Email address is invalid";
			}
	
			 if (str.indexOf(at,(lat+1))!=-1){
			    return "Email address is invalid";
			 }
	
			 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
			    return "Email address is invalid";
			 }
	
			 if (str.indexOf(dot,(lat+2))==-1){
			    return "Email address is invalid";
			 }
			
			 if (str.indexOf(" ")!=-1){
			    return "Email addres is invalid";
			 }
	
	 		 return "";					
		}   	   	