<?php
   class ImagesController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
