<?php
   class SolutionsController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
