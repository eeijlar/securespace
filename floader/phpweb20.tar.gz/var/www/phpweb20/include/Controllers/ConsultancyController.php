<?php
   class ConsultancyController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
