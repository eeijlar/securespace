<?php
    class ClientsController extends CustomControllerAction
    {
    	public function indexAction(){
    		
    		
    	}
    
    }
?>
