<?php
   class TrainingController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
