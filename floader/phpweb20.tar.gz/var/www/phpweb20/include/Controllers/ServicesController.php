<?php
   class ServicesController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
