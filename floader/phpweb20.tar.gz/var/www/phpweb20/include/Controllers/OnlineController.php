<?php
   class OnlineController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
