<?php
   class ContactController extends CustomControllerAction
    {
        public function indexAction()
        {

        }
    }
?>
